import re

def verificar_sintaxis_for(codigo):
    errores = []

    # Verificar si la palabra 'for' está presente en el código
    if 'for' not in codigo:
        errores.append("Error sintáctico: Falta el bucle 'for'.")
    else:
        # Verificar si la palabra clave 'for' está seguida por un espacio
        index_for = codigo.find('for')
        if index_for != 0 and codigo[index_for - 1] != ' ':
            errores.append(f"Error sintáctico: La palabra clave '{codigo[index_for: index_for + 3]}' debe estar seguida por un espacio.")

        # Verificar si el bucle 'for' sigue el patrón esperado
        patron_for = r'\bfor\s*\(\s*\w+\s*=\s*\d+\s*;\s*\w+\s*[<>]=?=\s*\d+\s*;\s*\w+\s*(?:[\+\-]{2})?\s*\)\s*\{'
        if not re.search(patron_for, codigo):
            errores.append(f"Error sintáctico: '{codigo}' es incorrecta.")

        # Verificar si los paréntesis están balanceados
        if codigo.count('(') != codigo.count(')'):
            errores.append("Error sintáctico: Paréntesis no balanceados.")

        # Verificar si los corchetes están balanceados
        if codigo.count('{') != codigo.count('}'):
            errores.append("Error sintáctico: Corchetes no balanceados.")

        # Verificar si los corchetes están en la misma línea
        if '{' in codigo and '}' in codigo:
            index_open = codigo.find('{')
            index_close = codigo.find('}')
            if codigo.count('{') != codigo.count('}') or index_open > index_close:
                errores.append("Error sintáctico: Los corchetes no están en la misma línea o están desbalanceados.")

        # Verificar las sentencias dentro del bucle 'for'
        sentencias = obtener_sentencias(codigo)
        for sentencia in sentencias:
            es_valida, error = verificar_sentencia(sentencia)
            if not es_valida:
                errores.append(error)

    if errores:
        return "\n".join(errores)
    else:
        return "La sintaxis es correcta."

def obtener_sentencias(codigo):
    # Encontrar el índice del inicio del bucle 'for'
    indice_inicio_for = codigo.find('for')
    # Encontrar el índice del primer corchete abierto después del 'for'
    indice_corchete_abierto = codigo.find('{', indice_inicio_for)
    # Encontrar el índice del último corchete cerrado antes del final del código
    indice_corchete_cerrado = codigo.rfind('}', indice_corchete_abierto)

    # Extraer el bloque de código dentro del bucle 'for'
    codigo_dentro_del_for = codigo[indice_corchete_abierto + 1 : indice_corchete_cerrado]
    # Dividir el bloque de código en líneas
    lineas = codigo_dentro_del_for.split('\n')
    # Filtrar las líneas que contienen sentencias
    sentencias = [linea.strip() for linea in lineas if ';' in linea]

    return sentencias

def verificar_sentencia(sentencia):
    # Verificar si la sentencia está vacía
    if not sentencia:
        return False, "La sentencia está vacía."

    # Verificar si la sentencia termina con ';'
    if not sentencia.endswith(';'):
        return False, f"Falta ';' al final de la sentencia: '{sentencia}'."

    # Verificar si la sentencia contiene comillas sin cerrar
    if sentencia.count('"') % 2 != 0:
        return False, f"Comillas sin cerrar en la sentencia: '{sentencia}'."

    # Verificar si la sentencia contiene un paréntesis abierto y uno cerrado
    if sentencia.count('(') != sentencia.count(')'):
        return False, f"Falta paréntesis en la sentencia: '{sentencia}'."

    # Verificar si la sentencia contiene 'system.' y 'out.'
    if 'system.' not in sentencia:
        return False, f"Sentencia no contiene 'system.': '{sentencia}'."

    if 'out.' not in sentencia:
        return False, f"Sentencia no contiene 'out.': '{sentencia}'."

    # Si llegamos a este punto, la sentencia parece estar bien estructurada
    return True, None


